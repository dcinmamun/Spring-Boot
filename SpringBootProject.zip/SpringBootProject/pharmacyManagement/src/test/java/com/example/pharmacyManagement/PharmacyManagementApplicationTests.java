package com.example.pharmacyManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmacyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
